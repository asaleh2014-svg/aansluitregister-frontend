import React, { useRef, useEffect } from 'react';
import { marked } from 'marked';

export const ParsedMarkdown: React.FC<{ text: string }> = ({ text }) => {
    const contentRef = useRef<HTMLDivElement>(null);
    const parsedHtml = marked.parse(text);

    useEffect(() => {
        if (contentRef.current) {
            // Sanitize links to open in a new tab
            const links = contentRef.current.querySelectorAll('a');
            links.forEach(link => {
                link.target = '_blank';
                link.rel = 'noopener noreferrer';
                link.className = 'text-cyan-400 hover:underline';
            });
            // Style lists
            const lists = contentRef.current.querySelectorAll('ul, ol');
            lists.forEach(list => {
                list.className = 'list-disc list-inside space-y-1 pl-2';
                 if (list.tagName === 'OL') {
                    list.className = 'list-decimal list-inside space-y-1 pl-2';
                }
            });
        }
    }, [parsedHtml]);

    return (
        <div 
            ref={contentRef}
            className="prose prose-sm prose-invert max-w-none"
            dangerouslySetInnerHTML={{ __html: parsedHtml as string }} 
        />
    );
};
import React, { useMemo, useState, useEffect } from 'react';
import { UserData, ProductType, ForecastDataPoint, Connection } from '../types';
import { fetchForecastCostData } from '../services/energyService';
import { ConnectionsIcon, ElectricityIcon, GasIcon, WaterIcon } from './icons/Icons';
import ConnectionsMap from './ConnectionsMap';
import CostForecastChart from './CostForecastChart';
import HistoricCostChart from './HistoricCostChart';
import AISummary from './AISummary';
import PortfolioCompositionChart from './PortfolioCompositionChart';

interface DashboardOverviewProps {
    user: UserData | null;
    onNavigateToConnections: () => void;
    onSelectConnection: (connection: Connection) => void;
}

const SummaryCard: React.FC<{
    title: string;
    icon: React.ReactNode;
    consumption: string;
    cost: string;
    period: string;
}> = ({ title, icon, consumption, cost, period }) => (
    <div className="bg-slate-800 p-4 rounded-lg border border-slate-700 flex flex-col justify-between">
        <div>
            <div className="flex items-center justify-between mb-4">
                <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">{title}</h3>
                {icon}
            </div>
            <div className="mb-2">
                <p className="text-4xl font-bold text-slate-100">{consumption}</p>
                 <p className="text-sm text-slate-400">Consumption</p>
            </div>
             <div>
                <p className="text-2xl font-semibold text-slate-200">{cost}</p>
                 <p className="text-sm text-slate-400">Forecasted Cost</p>
            </div>
        </div>
        <div className="mt-4 pt-2 border-t border-slate-700">
             <p className="text-xs text-slate-500 text-center">{period}</p>
        </div>
    </div>
);


const DashboardOverview: React.FC<DashboardOverviewProps> = ({ user, onNavigateToConnections, onSelectConnection }) => {
    
    const [forecasts, setForecasts] = useState<{
        elek: ForecastDataPoint[],
        gas: ForecastDataPoint[],
        water: ForecastDataPoint[],
    }>({ elek: [], gas: [], water: [] });

    useEffect(() => {
        const loadForecasts = async () => {
            const [elekData, gasData, waterData] = await Promise.all([
                fetchForecastCostData(ProductType.ELEKTRA),
                fetchForecastCostData(ProductType.GAS),
                fetchForecastCostData(ProductType.WATER),
            ]);
            setForecasts({ elek: elekData, gas: gasData, water: waterData });
        };
        loadForecasts();
    }, []);
    
    const summaryStats = useMemo(() => {
        if (!user) return {
            totalElekConsumption: 0,
            totalGasConsumption: 0,
            totalWaterConsumption: 0,
            currentYearElekCost: 0,
            currentYearGasCost: 0,
            currentYearWaterCost: 0,
            elekPeriod: 'N/A',
            gasPeriod: 'N/A',
            waterPeriod: 'N/A',
        };
        
        const calculateTotalConsumption = (product: ProductType) => {
             return user.connections
                .filter(c => c.product === product)
                .reduce((acc, c) => acc + c.consumption.reduce((sum, d) => sum + d.usage, 0), 0);
        };

        const calculateCurrentYearCost = (data: ForecastDataPoint[]) => {
            const currentYearSuffix = `'${new Date().getFullYear().toString().substring(2)}'`;
            return data
                .filter(d => d.month.endsWith(currentYearSuffix))
                .reduce((sum, d) => sum + d.commodity + d.nonCommodity, 0);
        };

        const formatDate = (date: Date) => {
            return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: '2-digit' }).replace(/ /g, '-');
        };

        const getPeriodForProduct = (product: ProductType): string => {
            const productConnections = user.connections.filter(c => c.product === product);
            if (productConnections.length === 0) return 'No data';
            
            const allDates = productConnections.flatMap(c => c.consumption.map(d => new Date(d.date).getTime()));
            if (allDates.length === 0) return 'No consumption data';
        
            const minDate = new Date(Math.min(...allDates));
            const maxDate = new Date(Math.max(...allDates));
        
            return `${formatDate(minDate)} until ${formatDate(maxDate)}`;
        };

        return {
            totalElekConsumption: calculateTotalConsumption(ProductType.ELEKTRA),
            totalGasConsumption: calculateTotalConsumption(ProductType.GAS),
            totalWaterConsumption: calculateTotalConsumption(ProductType.WATER),
            currentYearElekCost: calculateCurrentYearCost(forecasts.elek),
            currentYearGasCost: calculateCurrentYearCost(forecasts.gas),
            currentYearWaterCost: calculateCurrentYearCost(forecasts.water),
            elekPeriod: getPeriodForProduct(ProductType.ELEKTRA),
            gasPeriod: getPeriodForProduct(ProductType.GAS),
            waterPeriod: getPeriodForProduct(ProductType.WATER),
        }

    }, [user, forecasts]);

    if (!user) return null;

    return (
        <div className="space-y-8">
            <div className="flex flex-wrap items-center justify-between gap-4">
                <h1 className="text-3xl font-bold text-slate-100">Dashboard Overview</h1>
                <button
                    onClick={onNavigateToConnections}
                    className="flex items-center justify-center px-6 py-3 text-sm font-medium text-white bg-cyan-600 border border-transparent rounded-md shadow-sm hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-cyan-500 transition-colors duration-300"
                >
                    <ConnectionsIcon className="w-5 h-5 mr-2" />
                    Go to Connections
                </button>
            </div>

            <AISummary connections={user.connections} />

            {/* Summary Cards */}
            <div>
                 <h2 className="text-lg font-semibold text-slate-300 mb-4">Actual Consumption: Current Year</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <SummaryCard 
                        title="Electricity"
                        consumption={`${(summaryStats.totalElekConsumption / 1000).toFixed(2)} MWh`}
                        cost={`€ ${summaryStats.currentYearElekCost.toLocaleString('nl-NL', {minimumFractionDigits: 2})}`}
                        period={summaryStats.elekPeriod}
                        icon={<ElectricityIcon className="w-6 h-6 text-yellow-400" />}
                    />
                     <SummaryCard 
                        title="Gas"
                        consumption={`${summaryStats.totalGasConsumption.toLocaleString('nl-NL', {maximumFractionDigits: 0})} m³`}
                        cost={`€ ${summaryStats.currentYearGasCost.toLocaleString('nl-NL', {minimumFractionDigits: 2})}`}
                        period={summaryStats.gasPeriod}
                        icon={<GasIcon className="w-6 h-6 text-sky-400" />}
                    />
                     <SummaryCard 
                        title="Water"
                        consumption={`${summaryStats.totalWaterConsumption.toLocaleString('nl-NL', {maximumFractionDigits: 0})} m³`}
                        cost={`€ ${summaryStats.currentYearWaterCost.toLocaleString('nl-NL', {minimumFractionDigits: 2})}`}
                        period={summaryStats.waterPeriod}
                        icon={<WaterIcon className="w-6 h-6 text-cyan-400" />}
                    />
                </div>
            </div>
            
            {/* Map and Charts */}
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
                <div className="bg-slate-800 rounded-lg border border-slate-700 p-6 min-h-[400px]">
                     <h2 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4">Connections Map</h2>
                     <ConnectionsMap connections={user.connections} onSelectConnection={onSelectConnection} />
                </div>
                 <div className="bg-slate-800 rounded-lg border border-slate-700 p-6 min-h-[400px]">
                     <CostForecastChart />
                </div>
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
                <div className="bg-slate-800 rounded-lg border border-slate-700 p-6">
                    <HistoricCostChart connections={user.connections} />
                </div>
                <div className="bg-slate-800 rounded-lg border border-slate-700 p-6">
                    <PortfolioCompositionChart connections={user.connections} />
                </div>
            </div>

        </div>
    );
};

export default DashboardOverview;
import React, { useState } from 'react';
import { Connection, ProductType, ConnectionType, ConnectionStatus } from '../types';

interface AddConnectionFormProps {
    onSave: (connection: Omit<Connection, 'id' | 'meters' | 'consumption'>) => void;
    onCancel: () => void;
}

const getTodayString = () => new Date().toISOString().split('T')[0];

const initialFormData = {
    product: ProductType.ELEKTRA,
    status: ConnectionStatus.ACTIVE,
    client: "",
    department: "",
    connectionName: "",
    ean: "",
    address: "",
    postalCode: "",
    city: "",
    country: "",
    latitude: 0,
    longitude: 0,
    connectionType: ConnectionType.SMALL,
    supplierInfo: {
        name: "",
        startDate: getTodayString(),
        endDate: getTodayString(),
        contact: ""
    },
    networkOperatorInfo: {
        name: "",
        contact: ""
    },
    technicalData: {
        capacity: "",
        physicalStatus: ""
    },
    notes: [],
};


const FormInput: React.FC<{
    label: string;
    name: string;
    value: string | number;
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    type?: string;
    required?: boolean;
}> = ({ label, name, value, onChange, type = 'text', required = false }) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-slate-300">{label}</label>
        <input
            type={type}
            name={name}
            id={name}
            value={value}
            onChange={onChange}
            required={required}
            className="mt-1 block w-full text-white bg-slate-700 border border-slate-600 rounded-md shadow-sm placeholder-slate-400 focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm p-2"
        />
    </div>
);

const FormSelect: React.FC<{
    label: string;
    name: string;
    value: string;
    onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
    options: string[];
}> = ({ label, name, value, onChange, options }) => (
     <div>
        <label htmlFor={name} className="block text-sm font-medium text-slate-300">{label}</label>
        <select
            name={name}
            id={name}
            value={value}
            onChange={onChange}
            className="mt-1 block w-full text-white bg-slate-700 border border-slate-600 rounded-md shadow-sm focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm p-2"
        >
            {options.map(opt => <option key={opt} value={opt}>{opt}</option>)}
        </select>
    </div>
);


const AddConnectionForm: React.FC<AddConnectionFormProps> = ({ onSave, onCancel }) => {
    const [formData, setFormData] = useState<Omit<Connection, 'id' | 'meters' | 'consumption'>>(initialFormData);
    
    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleNestedChange = (e: React.ChangeEvent<HTMLInputElement>, section: 'supplierInfo' | 'networkOperatorInfo' | 'technicalData') => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [section]: {
                ...(prev[section]),
                [name]: value
            }
        }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave(formData);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-8 bg-slate-800 p-8 rounded-lg border border-slate-700">
            <div>
                 <h2 className="text-2xl font-bold text-slate-100">Add New Connection</h2>
                 <p className="text-slate-400">Fill in the details for the new connection point.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t border-slate-700 pt-6">
                 <h3 className="text-lg font-semibold text-slate-200 md:col-span-2">Core Information</h3>
                 <FormInput label="EAN Code" name="ean" value={formData.ean} onChange={handleChange} required />
                 <FormInput label="Connection Name" name="connectionName" value={formData.connectionName} onChange={handleChange} required />
                 <FormInput label="Client" name="client" value={formData.client} onChange={handleChange} />
                 <FormInput label="Department" name="department" value={formData.department} onChange={handleChange} />
                 <FormSelect label="Product" name="product" value={formData.product} onChange={handleChange} options={Object.values(ProductType)} />
                 <FormSelect label="Status" name="status" value={formData.status} onChange={handleChange} options={Object.values(ConnectionStatus)} />
            </div>

             <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t border-slate-700 pt-6">
                 <h3 className="text-lg font-semibold text-slate-200 md:col-span-2">Location Details</h3>
                 <FormInput label="Address" name="address" value={formData.address} onChange={handleChange} required />
                 <FormInput label="Postal Code" name="postalCode" value={formData.postalCode} onChange={handleChange} />
                 <FormInput label="City" name="city" value={formData.city} onChange={handleChange} required />
                 <FormInput label="Country" name="country" value={formData.country} onChange={handleChange} required />
                 <FormInput label="Latitude" name="latitude" type="number" value={formData.latitude} onChange={handleChange} />
                 <FormInput label="Longitude" name="longitude" type="number" value={formData.longitude} onChange={handleChange} />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t border-slate-700 pt-6">
                 <h3 className="text-lg font-semibold text-slate-200 md:col-span-2">Supplier & Operator</h3>
                 <FormInput label="Supplier Name" name="name" value={formData.supplierInfo.name} onChange={e => handleNestedChange(e, 'supplierInfo')} />
                 <FormInput label="Supplier Contact" name="contact" value={formData.supplierInfo.contact} onChange={e => handleNestedChange(e, 'supplierInfo')} />
                 <FormInput label="Delivery Start" name="startDate" type="date" value={formData.supplierInfo.startDate} onChange={e => handleNestedChange(e, 'supplierInfo')} />
                 <FormInput label="Delivery End" name="endDate" type="date" value={formData.supplierInfo.endDate} onChange={e => handleNestedChange(e, 'supplierInfo')} />
                 <FormInput label="Network Operator Name" name="name" value={formData.networkOperatorInfo.name} onChange={e => handleNestedChange(e, 'networkOperatorInfo')} />
                 <FormInput label="Network Operator Contact" name="contact" value={formData.networkOperatorInfo.contact} onChange={e => handleNestedChange(e, 'networkOperatorInfo')} />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t border-slate-700 pt-6">
                 <h3 className="text-lg font-semibold text-slate-200 md:col-span-2">Technical Data</h3>
                 <FormSelect label="Connection Type" name="connectionType" value={formData.connectionType} onChange={handleChange} options={Object.values(ConnectionType)} />
                 <FormInput label="Capacity" name="capacity" value={formData.technicalData.capacity} onChange={e => handleNestedChange(e, 'technicalData')} />
                 <FormInput label="Physical Status" name="physicalStatus" value={formData.technicalData.physicalStatus} onChange={e => handleNestedChange(e, 'technicalData')} />
            </div>

            <div className="flex justify-end space-x-4 pt-6 border-t border-slate-700">
                <button type="button" onClick={onCancel} className="px-6 py-2 text-sm font-medium bg-slate-700 border border-slate-600 rounded-md shadow-sm text-slate-200 hover:bg-slate-600">
                    Cancel
                </button>
                <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-cyan-600 border border-transparent rounded-md shadow-sm hover:bg-cyan-700">
                    Save Connection
                </button>
            </div>
        </form>
    );
};

export default AddConnectionForm;
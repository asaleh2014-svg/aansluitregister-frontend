import React, { useState } from 'react';
import { LogoIcon, UserIcon, LockIcon } from './icons/Icons';
import { UserData } from '../types';

interface LoginPageProps {
  onLogin: (user: UserData) => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, password }),
        });

        if (response.ok) {
            const userData: UserData = await response.json();
            onLogin(userData);
        } else {
            const errorData = await response.json();
            setError(errorData.message || "Invalid email or password. Please use one of the demo accounts.");
        }
    } catch (err) {
        setError("Failed to connect to the server. Did you run 'npm run start:backend' in the terminal?");
        console.error("Login error:", err);
    } finally {
        setIsLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-slate-900">
      <div className="w-full max-w-md p-8 space-y-8 bg-slate-800 rounded-2xl shadow-lg border border-slate-700">
        <div className="flex flex-col items-center">
          <LogoIcon className="w-16 h-16 text-cyan-500" />
          <h1 className="mt-4 text-3xl font-bold text-center text-slate-100">
            Aansluitregister
          </h1>
          <p className="mt-2 text-center text-slate-400">
            Sign in to your energy dashboard
          </p>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          
          {error && (
            <div className="p-3 text-sm text-red-400 bg-red-500/10 border border-red-500/30 rounded-md">
                {error}
            </div>
          )}

          <div className="relative">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <UserIcon className="w-5 h-5 text-slate-400" />
            </div>
            <input
              id="email-address"
              name="email"
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full py-3 pl-10 pr-4 text-white bg-slate-700 border border-slate-600 rounded-md placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-cyan-500/75 focus:border-cyan-500 transition-shadow duration-300 shadow-sm focus:shadow-lg focus:shadow-cyan-500/20"
              placeholder="Email address"
            />
          </div>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <LockIcon className="w-5 h-5 text-slate-400" />
            </div>
            <input
              id="password"
              name="password"
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full py-3 pl-10 pr-4 text-white bg-slate-700 border border-slate-600 rounded-md placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-cyan-500/75 focus:border-cyan-500 transition-shadow duration-300 shadow-sm focus:shadow-lg focus:shadow-cyan-500/20"
              placeholder="Password"
            />
          </div>

          <div>
            <button
              type="submit"
              disabled={isLoading}
              className="flex justify-center w-full px-4 py-3 text-sm font-medium text-white bg-cyan-600 border border-transparent rounded-md shadow-sm hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500 disabled:bg-cyan-800 disabled:cursor-not-allowed transition-colors duration-300"
            >
              {isLoading ? (
                <div className="flex items-center">
                  <svg className="w-5 h-5 mr-3 text-white animate-spin" xmlns="http://www.w.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  <span>Signing In...</span>
                </div>
              ) : (
                'Sign In'
              )}
            </button>
          </div>
        </form>
         <div className="mt-6 text-xs text-center text-slate-400">
            <p className="font-semibold">Demo Accounts</p>
            <p>User: <code>1@1.com</code> (password is <code>1</code>)</p>
            <p>User: <code>2@2.com</code> (password is <code>2</code>)</p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
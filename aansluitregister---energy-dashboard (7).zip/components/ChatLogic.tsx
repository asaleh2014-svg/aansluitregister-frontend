import { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import { ChatMessage, Connection, GroundingSource } from '../types';

export const useChatLogic = (connections: Connection[]) => {
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [isLoading, setIsLoading] = useState(false);

    const handleSendMessage = async (message: string) => {
        const userMessage: ChatMessage = { role: 'user', text: message };
        setMessages(prev => [...prev, userMessage]);
        setIsLoading(true);

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
            
            const systemInstruction = `You are an AI assistant for an energy dashboard called "Aansluitregister". Your role is to help users analyze their energy connection data. You can also access Google Search for up-to-date, real-world information.

When a user asks a question, first determine if it can be answered using the provided connection data. If so, use that data as your primary source. If the question is about external topics, recent events, or requires information not present in the data (like current market prices, regulations, etc.), use your search tool.

-   The user's available connection data is provided below as a JSON object.
-   Be friendly, helpful, and use Markdown for formatting all your answers (e.g., bolding, lists).
-   When asked to provide data that could be in a table, format it as a Markdown table.
-   Always refer to the data provided when applicable. Do not invent information.
-   If the user's query is unclear or cannot be answered with the data or search, ask for clarification.

Here is the user's connection data:
${JSON.stringify(connections, null, 2)}`;

            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: {
                    role: 'user',
                    parts: [{ text: message }]
                },
                config: {
                    systemInstruction: systemInstruction,
                    tools: [{googleSearch: {}}],
                },
            });

            const sources: GroundingSource[] = response.candidates?.[0]?.groundingMetadata?.groundingChunks
                ?.map(chunk => chunk.web)
                .filter((web): web is { uri: string; title: string; } => !!web && !!web.uri && !!web.title) || [];
            
            const modelMessage: ChatMessage = {
                role: 'model',
                text: response.text,
                sources: sources,
            };
            setMessages(prev => [...prev, modelMessage]);

        } catch (error) {
            console.error("Error calling Gemini API:", error);
            const errorMessage: ChatMessage = {
                role: 'model',
                text: "Sorry, I encountered an error trying to process your request. Please check the console for details and try again."
            };
            setMessages(prev => [...prev, errorMessage]);
        } finally {
            setIsLoading(false);
        }
    };

    return { messages, isLoading, handleSendMessage };
};
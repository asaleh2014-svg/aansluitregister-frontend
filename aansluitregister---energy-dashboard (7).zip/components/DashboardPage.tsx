import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { UserData, Connection, ConnectionStatus, ProductType, ConnectionType, EditHistoryEntry } from '../types';
import ConnectionList from './ConnectionList';
import ConnectionDetails from './ConnectionDetails';
import FilterPanel, { FilterState } from './FilterPanel';
import { LogoIcon, LogoutIcon } from './icons/Icons';
import DashboardOverview from './DashboardOverview';
import AddConnectionForm from './AddConnectionForm';
import ChatWidget from './ChatWidget';
import { useChatLogic } from './ChatLogic';

interface DashboardPageProps {
  user: UserData;
  onLogout: () => void;
}

const initialFilterState: FilterState = {
    client: 'All',
    department: '',
    connectionName: '',
    ean: '',
    address: '',
    city: '',
    country: '',
    product: 'All',
    connectionType: 'All',
    status: 'All',
};

const ITEMS_PER_PAGE = 10;
export type SortableKeys = keyof Pick<Connection, 'product' | 'client' | 'department' | 'connectionName' | 'ean' | 'address' | 'postalCode' | 'city' | 'country' | 'connectionType' | 'status'> | 'annualConsumption';
type DashboardView = 'overview' | 'connections';

const DashboardPage: React.FC<DashboardPageProps> = ({ user, onLogout }) => {
  const [userData, setUserData] = useState<UserData>(user);
  const [selectedConnectionId, setSelectedConnectionId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false); // Kept for potential future async operations inside dashboard
  const [filters, setFilters] = useState<FilterState>(initialFilterState);
  const [currentPage, setCurrentPage] = useState(1);
  const [sortConfig, setSortConfig] = useState<{ key: SortableKeys; direction: 'ascending' | 'descending' } | null>({ key: 'client', direction: 'ascending' });
  const [currentView, setCurrentView] = useState<DashboardView>('overview');
  const [isAddingConnection, setIsAddingConnection] = useState(false);
  
  const { messages, isLoading: isChatLoading, handleSendMessage } = useChatLogic(userData?.connections || []);
  
  // Sync state if user prop changes (e.g. re-login as different user)
  useEffect(() => {
    setUserData(user);
    // Reset view when user changes
    setCurrentView('overview');
    setSelectedConnectionId(null);
    setIsAddingConnection(false);
    setFilters(initialFilterState);
  }, [user]);

  const accessibleClients = useMemo(() => user?.accessibleClients || [], [user]);

  const selectedConnection = useMemo(() => {
    if (!userData || !selectedConnectionId) return null;
    return userData.connections.find(c => c.id === selectedConnectionId) || null;
  }, [userData, selectedConnectionId]);

  const handleUpdateConnection = (updatedData: Connection) => {
    setUserData(currentUserData => {
        if (!currentUserData) return currentUserData;

        const index = currentUserData.connections.findIndex(c => c.id === updatedData.id);
        if (index === -1) return currentUserData;

        const originalConnection = currentUserData.connections[index];

        const snapshot = JSON.parse(JSON.stringify(originalConnection));
        const newHistoryEntry: EditHistoryEntry = {
            date: new Date().toISOString(),
            user: currentUserData.name,
            snapshot: snapshot,
        };

        const newHistory = [...(originalConnection.editHistory || []), newHistoryEntry];
        
        const finalUpdatedConnection = {
            ...updatedData,
            editHistory: newHistory,
        };

        const newConnections = [...currentUserData.connections];
        newConnections[index] = finalUpdatedConnection;

        return {
            ...currentUserData,
            connections: newConnections,
        };
    });
  };

  const handleSaveNewConnection = (connectionData: Omit<Connection, 'id' | 'meters' | 'consumption'>) => {
    const newConnection: Connection = {
        ...connectionData,
        id: `conn-${Date.now()}`,
        meters: [],
        consumption: [],
        editHistory: [],
    };
    setUserData(prev => {
        if (!prev) return prev;
        return { ...prev, connections: [...prev.connections, newConnection]};
    });
    setIsAddingConnection(false);
    setCurrentView('connections');
  };

  const filteredConnections = useMemo(() => {
    if (!userData) return [];

    return userData.connections.filter(conn => {
        if (filters.client !== 'All' && conn.client !== filters.client) return false;
        if (filters.department && !conn.department.toLowerCase().includes(filters.department.toLowerCase())) return false;
        if (filters.connectionName && !conn.connectionName.toLowerCase().includes(filters.connectionName.toLowerCase())) return false;
        if (filters.ean && !conn.ean.toLowerCase().includes(filters.ean.toLowerCase())) return false;
        if (filters.address && !conn.address.toLowerCase().includes(filters.address.toLowerCase())) return false;
        if (filters.city && !conn.city.toLowerCase().includes(filters.city.toLowerCase())) return false;
        if (filters.country && !conn.country.toLowerCase().includes(filters.country.toLowerCase())) return false;
        if (filters.product !== 'All' && conn.product !== filters.product) return false;
        if (filters.connectionType !== 'All' && conn.connectionType !== filters.connectionType) return false;
        if (filters.status !== 'All' && conn.status !== filters.status) return false;
        
        return true;
    });
  }, [userData, filters]);

  const sortedConnections = useMemo(() => {
    let sortableItems = [...filteredConnections];
    if (sortConfig !== null) {
        sortableItems.sort((a, b) => {
            if (sortConfig.key === 'annualConsumption') {
                const calcAnnual = (conn: Connection) => conn.consumption.length > 0 ? (conn.consumption.reduce((sum, item) => sum + item.usage, 0) / conn.consumption.length) * 365 : 0;
                const aVal = calcAnnual(a);
                const bVal = calcAnnual(b);
                if (aVal < bVal) return sortConfig.direction === 'ascending' ? -1 : 1;
                if (aVal > bVal) return sortConfig.direction === 'ascending' ? 1 : -1;
                return 0;
            }

            const aVal = a[sortConfig.key as keyof Connection];
            const bVal = b[sortConfig.key as keyof Connection];
           
            const valA = typeof aVal === 'number' ? aVal : String(aVal).toLowerCase();
            const valB = typeof bVal === 'number' ? bVal : String(bVal).toLowerCase();

            if (valA < valB) {
                return sortConfig.direction === 'ascending' ? -1 : 1;
            }
            if (valA > valB) {
                return sortConfig.direction === 'ascending' ? 1 : -1;
            }
            return 0;
        });
    }
    return sortableItems;
  }, [filteredConnections, sortConfig]);

  const paginatedConnections = useMemo(() => {
    const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
    return sortedConnections.slice(startIndex, startIndex + ITEMS_PER_PAGE);
  }, [sortedConnections, currentPage]);

  const totalPages = Math.ceil(sortedConnections.length / ITEMS_PER_PAGE);

  const handleSelectConnection = (connection: Connection) => {
    setSelectedConnectionId(connection.id);
    setIsAddingConnection(false);
  };
  
  const handleGoBack = () => {
      setSelectedConnectionId(null);
      setIsAddingConnection(false);
  }

  const handleFilterChange = (newFilters: FilterState) => {
      setFilters(newFilters);
      setSelectedConnectionId(null);
      setCurrentPage(1);
  };
  
  const handleResetFilters = useCallback(() => {
    setFilters(initialFilterState);
    setSelectedConnectionId(null);
    setCurrentPage(1);
  }, []);
  
  const handleSort = (key: SortableKeys) => {
    let direction: 'ascending' | 'descending' = 'ascending';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'ascending') {
        direction = 'descending';
    }
    setSortConfig({ key, direction });
  };
  
  const handleShowAddForm = () => {
    setSelectedConnectionId(null);
    setIsAddingConnection(true);
  };

  const renderContent = () => {
    if (isAddingConnection) {
        return (
            <div className="w-full p-4 md:p-6 lg:p-8 overflow-y-auto">
                <AddConnectionForm 
                    onSave={handleSaveNewConnection}
                    onCancel={() => setIsAddingConnection(false)}
                />
            </div>
        );
    }
    
    if (selectedConnection) {
        return (
            <div className="w-full p-4 md:p-6 lg:p-8 overflow-y-auto">
                <ConnectionDetails 
                    connection={selectedConnection} 
                    onBack={handleGoBack}
                    onUpdateConnection={handleUpdateConnection}
                    user={userData}
                />
            </div>
        );
    }
    
    if (currentView === 'connections') {
      return (
        <>
            <aside className="w-1/4 xl:w-1/5 bg-slate-800/50 border-r border-slate-700 p-4 overflow-y-auto flex-shrink-0">
                <FilterPanel 
                    filters={filters} 
                    onFilterChange={handleFilterChange}
                    onReset={handleResetFilters}
                    accessibleClients={accessibleClients}
                />
            </aside>
            <div className="w-3/4 xl:w-4/5 p-4 md:p-6 lg:p-8 overflow-y-auto">
                <ConnectionList
                    connections={paginatedConnections}
                    onSelectConnection={handleSelectConnection}
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={setCurrentPage}
                    totalResults={sortedConnections.length}
                    itemsPerPage={ITEMS_PER_PAGE}
                    sortConfig={sortConfig}
                    onSort={handleSort}
                    onBackToDashboard={() => { setCurrentView('overview'); setIsAddingConnection(false); }}
                    onAddNew={handleShowAddForm}
                />
            </div>
        </>
      );
    }
    
    return (
        <div className="w-full p-4 md:p-6 lg:p-8 overflow-y-auto">
            <DashboardOverview 
                user={userData}
                onNavigateToConnections={() => { setCurrentView('connections'); setIsAddingConnection(false); }}
                onSelectConnection={handleSelectConnection}
            />
        </div>
    );
  };

  return (
    <div className="flex flex-col h-screen bg-slate-900">
      <header className="flex items-center justify-between p-4 bg-slate-800/50 backdrop-blur-sm border-b border-slate-700 flex-shrink-0 z-10">
        <div className="flex items-center space-x-3">
          <LogoIcon className="w-10 h-10 text-cyan-500" />
          <h1 className="text-2xl font-semibold text-slate-200">Aansluitregister</h1>
        </div>
        <div className="flex items-center space-x-4">
            <span className="hidden sm:block text-slate-400">Welcome, {userData?.name}</span>
            <button
              onClick={onLogout}
              className="p-2 text-slate-400 rounded-full hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500"
              aria-label="Logout"
            >
              <LogoutIcon className="w-6 h-6" />
            </button>
        </div>
      </header>
      <main className="flex flex-grow overflow-hidden">
        {isLoading ? (
          <div className="flex items-center justify-center w-full">
            <svg className="w-12 h-12 text-cyan-500 animate-spin" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
          </div>
        ) : (
          <div className="flex w-full">
            {userData ? renderContent() : <div className="flex items-center justify-center w-full">No user data available.</div>}
          </div>
        )}
      </main>
      <ChatWidget 
        messages={messages} 
        onSendMessage={handleSendMessage} 
        isLoading={isChatLoading}
      />
    </div>
  );
};

export default DashboardPage;
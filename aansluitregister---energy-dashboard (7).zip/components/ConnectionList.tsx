import React from 'react';
import { Connection, ProductType, ConnectionStatus } from '../types';
import { SortableKeys } from './DashboardPage';
import { ArrowUpIcon, ArrowDownIcon, BackIcon } from './icons/Icons';

interface ConnectionListProps {
  connections: Connection[];
  onSelectConnection: (connection: Connection) => void;
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
  totalResults: number;
  itemsPerPage: number;
  sortConfig: { key: SortableKeys; direction: 'ascending' | 'descending' } | null;
  onSort: (key: SortableKeys) => void;
  onBackToDashboard: () => void;
  onAddNew: () => void;
}

const StatusIcon: React.FC<{ status: ConnectionStatus }> = ({ status }) => {
    const isActive = status === ConnectionStatus.ACTIVE;
    return (
        <div className={`w-6 h-6 rounded-full ${isActive ? 'bg-green-500/10' : 'bg-red-500/10'} flex items-center justify-center`} title={status}>
            <div className={`w-3 h-3 rounded-full ${isActive ? 'bg-green-500' : 'bg-red-500'}`}></div>
        </div>
    );
};

interface PaginationProps {
    currentPage: number;
    totalPages: number;
    onPageChange: (page: number) => void;
}

const Pagination: React.FC<PaginationProps> = ({ currentPage, totalPages, onPageChange }) => {
    if (totalPages <= 1) return null;

    const pageNumbers: (number | string)[] = [];
    const maxPagesToShow = 10;
    
    if (totalPages <= maxPagesToShow) {
        for (let i = 1; i <= totalPages; i++) {
            pageNumbers.push(i);
        }
    } else {
        pageNumbers.push(1);
        if (currentPage > 4) pageNumbers.push('...');
        
        let start = Math.max(2, currentPage - 2);
        let end = Math.min(totalPages - 1, currentPage + 2);

        if (currentPage <= 4) end = 5;
        if (currentPage >= totalPages - 3) start = totalPages - 4;

        for (let i = start; i <= end; i++) pageNumbers.push(i);

        if (currentPage < totalPages - 3) pageNumbers.push('...');
        pageNumbers.push(totalPages);
    }
    
    return (
        <nav className="flex items-center space-x-1">
            <button onClick={() => onPageChange(currentPage - 1)} disabled={currentPage === 1} className="px-3 py-1 rounded-md text-sm border border-slate-600 disabled:opacity-50 disabled:cursor-not-allowed">&lt;</button>
            {pageNumbers.map((num, index) => (
                <button 
                    key={index} 
                    onClick={() => typeof num === 'number' && onPageChange(num)}
                    disabled={typeof num !== 'number'}
                    className={`px-3 py-1 rounded-md text-sm ${currentPage === num ? 'bg-cyan-600 text-white border-cyan-600' : 'bg-slate-800 text-slate-300 border border-slate-600 hover:bg-slate-700'} ${typeof num !== 'number' ? 'cursor-default' : ''}`}>
                    {num}
                </button>
            ))}
            <button onClick={() => onPageChange(currentPage + 1)} disabled={currentPage === totalPages} className="px-3 py-1 rounded-md text-sm border border-slate-600 disabled:opacity-50 disabled:cursor-not-allowed">&gt;</button>
        </nav>
    );
};

const SortableHeader: React.FC<{
    columnKey: SortableKeys;
    title: string;
    onSort: (key: SortableKeys) => void;
    sortConfig: { key: SortableKeys; direction: 'ascending' | 'descending' } | null;
}> = ({ columnKey, title, onSort, sortConfig }) => {
    const isSorted = sortConfig?.key === columnKey;
    const direction = sortConfig?.direction;

    return (
        <th className="py-3 px-4 text-left text-xs font-semibold text-slate-400 uppercase tracking-wider">
            <button onClick={() => onSort(columnKey)} className="flex items-center space-x-1 hover:text-slate-200">
                <span>{title}</span>
                {isSorted && (
                    direction === 'ascending' 
                    ? <ArrowUpIcon className="w-3 h-3"/> 
                    : <ArrowDownIcon className="w-3 h-3"/>
                )}
            </button>
        </th>
    );
};

const ConnectionList: React.FC<ConnectionListProps> = ({ connections, onSelectConnection, currentPage, totalPages, onPageChange, totalResults, itemsPerPage, sortConfig, onSort, onBackToDashboard, onAddNew }) => {
  const startItem = totalResults > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0;
  const endItem = Math.min(startItem + itemsPerPage - 1, totalResults);
  
  return (
    <div className="h-full">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
            <button
                onClick={onBackToDashboard}
                className="flex items-center px-4 py-2 text-sm font-medium bg-slate-700 border border-slate-600 rounded-md shadow-sm text-slate-200 hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-cyan-500"
            >
                <BackIcon className="w-5 h-5 mr-2" />
                Back to Dashboard
            </button>
            <button
                onClick={onAddNew}
                className="px-4 py-2 text-sm font-medium text-white bg-cyan-600 border border-transparent rounded-md shadow-sm hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-cyan-500"
            >
                Add New Connection
            </button>
        </div>


      <h1 className="text-3xl font-bold text-slate-100 mb-6">
        Connections
      </h1>
      
       <div className="bg-slate-800 rounded-lg border border-slate-700">
        <div className="p-4 flex flex-wrap items-center justify-between gap-4 border-b border-slate-700">
             <p className="text-sm text-slate-400">
                {totalResults > 0 ? `Showing ${startItem} to ${endItem} of ${totalResults} results` : 'No results found'}
            </p>
            <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={onPageChange} />
        </div>
      
        <div className="overflow-x-auto">
            <table className="min-w-full">
            <thead className="bg-slate-700/50">
                <tr className="border-b border-slate-700">
                <th className="py-3 px-4 text-left text-xs font-semibold text-slate-400 uppercase tracking-wider w-12">Status</th>
                <SortableHeader columnKey="product" title="Product" onSort={onSort} sortConfig={sortConfig} />
                <SortableHeader columnKey="client" title="Client" onSort={onSort} sortConfig={sortConfig} />
                <SortableHeader columnKey="department" title="Department" onSort={onSort} sortConfig={sortConfig} />
                <SortableHeader columnKey="connectionName" title="Connection Name" onSort={onSort} sortConfig={sortConfig} />
                <SortableHeader columnKey="ean" title="EAN Code" onSort={onSort} sortConfig={sortConfig} />
                <SortableHeader columnKey="address" title="Address" onSort={onSort} sortConfig={sortConfig} />
                <SortableHeader columnKey="postalCode" title="Postal Code" onSort={onSort} sortConfig={sortConfig} />
                <SortableHeader columnKey="city" title="City" onSort={onSort} sortConfig={sortConfig} />
                <SortableHeader columnKey="country" title="Country" onSort={onSort} sortConfig={sortConfig} />
                <SortableHeader columnKey="annualConsumption" title="Annual Consumption" onSort={onSort} sortConfig={sortConfig} />
                </tr>
            </thead>
            <tbody className="divide-y divide-slate-700">
                {connections.map(conn => {
                const totalConsumption = conn.consumption.reduce((sum, item) => sum + item.usage, 0);
                const annualConsumption = conn.consumption.length > 0 ? (totalConsumption / conn.consumption.length) * 365 : 0;
                const unit = conn.product === ProductType.WATER ? 'm³' : 'kWh';

                return (
                    <tr key={conn.id} onClick={() => onSelectConnection(conn)} className="hover:bg-slate-700/50 cursor-pointer transition-colors duration-150">
                    <td className="py-3 px-4"><StatusIcon status={conn.status} /></td>
                    <td className="py-3 px-4 text-sm text-slate-200 whitespace-nowrap">{conn.product}</td>
                    <td className="py-3 px-4 text-sm text-slate-200 whitespace-nowrap">{conn.client}</td>
                    <td className="py-3 px-4 text-sm text-slate-200 whitespace-nowrap">{conn.department}</td>
                    <td className="py-3 px-4 text-sm text-slate-200 whitespace-nowrap">{conn.connectionName}</td>
                    <td className="py-3 px-4 text-sm text-slate-200 whitespace-nowrap">{conn.ean}</td>
                    <td className="py-3 px-4 text-sm text-slate-200 whitespace-nowrap">{conn.address}</td>
                    <td className="py-3 px-4 text-sm text-slate-200 whitespace-nowrap">{conn.postalCode}</td>
                    <td className="py-3 px-4 text-sm text-slate-200 whitespace-nowrap">{conn.city}</td>
                    <td className="py-3 px-4 text-sm text-slate-200 whitespace-nowrap">{conn.country}</td>
                    <td className="py-3 px-4 text-sm text-slate-200 whitespace-nowrap">{`${annualConsumption.toLocaleString(undefined, { maximumFractionDigits: 0 })} ${unit}`}</td>
                    </tr>
                )
                })}
            </tbody>
            </table>
            {connections.length === 0 && (
            <div className="text-center py-16">
                <p className="text-slate-400">No connections match the current filters.</p>
            </div>
        )}
        </div>
      </div>
    </div>
  );
};

export default ConnectionList;
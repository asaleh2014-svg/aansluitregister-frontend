import React, { useState, useCallback } from 'react';
import { GoogleGenAI } from '@google/genai';
import { Connection } from '../types';
import { SparklesIcon } from './icons/Icons';
import { ParsedMarkdown } from './ParsedMarkdown';

interface AISummaryProps {
    connections: Connection[];
}

const AISummary: React.FC<AISummaryProps> = ({ connections }) => {
    const [summary, setSummary] = useState<string>('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string>('');

    const generateSummary = useCallback(async () => {
        setIsLoading(true);
        setError('');
        setSummary('');

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
            
            const systemInstruction = `You are an expert energy portfolio analyst. Your task is to provide a concise, insightful summary based on the user's energy connection data. The output should be in Markdown format.

Analyze the provided JSON data which contains a list of energy connections. In your summary, please:
1.  Provide a brief, high-level overview of the portfolio (e.g., number of connections, types of products).
2.  Identify the top 1-2 connections with the highest annual consumption and mention their client and product type. Calculate annual consumption by averaging the daily consumption provided and multiplying by 365.
3.  Highlight any connections that are currently 'Inactive'.
4.  Offer one or two clear, actionable recommendations for potential energy or cost savings, based on the data. For example, suggest reviewing the highest consumers or investigating inactive connections.
5.  Keep the entire summary to 3-4 bullet points for easy readability.

Do not output JSON or any other format besides Markdown.`;

            const prompt = `Here is the connection data:
${JSON.stringify(connections, null, 2)}`;

            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: { role: 'user', parts: [{ text: prompt }] },
                config: {
                    systemInstruction: systemInstruction,
                },
            });
            
            const responseText = response.text;
            setSummary(responseText);

        } catch (err) {
            console.error("Error generating AI summary:", err);
            setError("Sorry, I couldn't generate a summary at this time. Please try again later.");
        } finally {
            setIsLoading(false);
        }
    }, [connections]);
    
    return (
        <div className="bg-slate-800 rounded-lg border border-slate-700 p-6">
            <h2 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4">AI-Powered Insights</h2>
            
            {isLoading && (
                <div className="flex items-center justify-center h-24">
                    <svg className="w-8 h-8 text-cyan-500 animate-spin" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"></path>
                    </svg>
                    <p className="ml-3 text-slate-300">Analyzing your portfolio...</p>
                </div>
            )}

            {error && (
                <div className="p-3 text-sm text-red-400 bg-red-500/10 border border-red-500/30 rounded-md">
                    {error}
                </div>
            )}

            {summary && !isLoading && (
                <div>
                    <ParsedMarkdown text={summary} />
                </div>
            )}

            {!isLoading && (
                <div className={`mt-4 ${summary ? 'flex justify-end' : 'flex justify-center'}`}>
                    <button
                        onClick={generateSummary}
                        className="flex items-center px-4 py-2 text-sm font-medium text-white bg-cyan-600 border border-transparent rounded-md shadow-sm hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-cyan-500 disabled:opacity-50"
                        disabled={isLoading}
                    >
                        <SparklesIcon className="w-5 h-5 mr-2" />
                        {summary ? 'Regenerate Summary' : 'Generate AI Summary'}
                    </button>
                </div>
            )}
        </div>
    );
};

export default AISummary;

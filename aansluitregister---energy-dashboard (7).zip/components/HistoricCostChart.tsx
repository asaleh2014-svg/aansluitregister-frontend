import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { HistoricProductCostPoint, ProductType, Connection } from '../types';
import { fetchHistoricCostByProduct, fetchHistoricCostForConnectionByProduct } from '../services/energyService';

const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const date = new Date(label);
      const formattedLabel = date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
      return (
        <div className="p-2 bg-slate-800 border border-slate-600 rounded-md shadow-lg">
          <p className="label font-bold text-slate-100">{formattedLabel}</p>
          {payload.map((pld: any) => (
            <p key={pld.dataKey} style={{ color: pld.stroke }}>
              {`${pld.name}: €${pld.value.toLocaleString('nl-NL', {minimumFractionDigits: 2})}`}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

interface HistoricCostChartProps {
    connections: Connection[];
}

const HistoricCostChart: React.FC<HistoricCostChartProps> = ({ connections }) => {
    const [costData, setCostData] = useState<HistoricProductCostPoint[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [selectedConnectionId, setSelectedConnectionId] = useState<string>('All');
    const [visibleProducts, setVisibleProducts] = useState({
        [ProductType.ELEKTRA]: true,
        [ProductType.GAS]: true,
        [ProductType.WATER]: true,
    });

    useEffect(() => {
        const loadData = async () => {
            setIsLoading(true);
            const data = selectedConnectionId === 'All'
                ? await fetchHistoricCostByProduct()
                : await fetchHistoricCostForConnectionByProduct(selectedConnectionId);
            setCostData(data);
            setIsLoading(false);
        };
        loadData();
    }, [selectedConnectionId]);

    const handleLegendClick = (data: any) => {
        const { dataKey } = data;
        if (dataKey) {
            setVisibleProducts(prev => ({
                ...prev,
                [dataKey]: !prev[dataKey as keyof typeof prev],
            }));
        }
    };

    const formatDate = (tick: string) => {
        const date = new Date(tick);
        return date.toLocaleDateString('en-US', { month: 'short', year: '2-digit' });
    };

    return (
        <div>
            <div className="flex flex-wrap items-center justify-between mb-4 gap-4">
                 <h2 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total Historic Cost by Product</h2>
                 <select
                    value={selectedConnectionId}
                    onChange={(e) => setSelectedConnectionId(e.target.value)}
                    className="block pl-3 pr-8 py-1.5 text-sm text-white bg-slate-700 border border-slate-600 rounded-md focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 max-w-xs"
                 >
                    <option value="All">All Connections</option>
                    {connections.map(conn => (
                        <option key={conn.id} value={conn.id}>
                            {conn.address}, {conn.city}
                        </option>
                    ))}
                 </select>
            </div>
            {isLoading ? (
                 <div className="flex items-center justify-center h-[300px]">
                    <svg className="w-8 h-8 text-cyan-500 animate-spin" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"></path>
                    </svg>
                 </div>
            ) : (
                <div style={{ width: '100%', height: 300 }}>
                    <ResponsiveContainer>
                        <LineChart data={costData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 255, 255, 0.1)" />
                            <XAxis 
                                dataKey="date" 
                                tickFormatter={formatDate}
                                tick={{ fill: '#94a3b8' }}
                                className="text-xs"
                            />
                            <YAxis 
                                tickFormatter={(value) => `€${value}`}
                                tick={{ fill: '#94a3b8' }} 
                                className="text-xs"
                            />
                            <Tooltip content={<CustomTooltip />} />
                            <Legend onClick={handleLegendClick} wrapperStyle={{ color: '#94a3b8' }} />
                            <Line type="monotone" dataKey={ProductType.ELEKTRA} name="Electricity Cost (€)" stroke="#f59e0b" strokeWidth={2} dot={false} hide={!visibleProducts[ProductType.ELEKTRA]} />
                            <Line type="monotone" dataKey={ProductType.GAS} name="Gas Cost (€)" stroke="#38bdf8" strokeWidth={2} dot={false} hide={!visibleProducts[ProductType.GAS]} />
                            <Line type="monotone" dataKey={ProductType.WATER} name="Water Cost (€)" stroke="#06b6d4" strokeWidth={2} dot={false} hide={!visibleProducts[ProductType.WATER]} />
                        </LineChart>
                    </ResponsiveContainer>
                </div>
            )}
        </div>
    );
};

export default HistoricCostChart;
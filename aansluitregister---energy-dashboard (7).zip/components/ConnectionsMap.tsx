import React from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import ReactDOMServer from 'react-dom/server';
import { Connection, ProductType } from '../types';
import { ElectricityIcon, GasIcon, WaterIcon } from './icons/Icons';

interface ConnectionsMapProps {
    connections: Connection[];
    onSelectConnection: (connection: Connection) => void;
}

const createIcon = (iconComponent: React.ReactElement) => {
    return L.divIcon({
        html: ReactDOMServer.renderToString(iconComponent),
        className: 'bg-transparent border-0',
        iconSize: [24, 24],
        iconAnchor: [12, 24],
        popupAnchor: [0, -24]
    });
};

const productIcons = {
    [ProductType.ELEKTRA]: createIcon(
        <div className="p-1.5 bg-yellow-400 rounded-full shadow-lg">
            <ElectricityIcon className="w-5 h-5 text-white" />
        </div>
    ),
    [ProductType.GAS]: createIcon(
        <div className="p-1.5 bg-blue-500 rounded-full shadow-lg">
            <GasIcon className="w-5 h-5 text-white" />
        </div>
    ),
    [ProductType.WATER]: createIcon(
        <div className="p-1.5 bg-cyan-500 rounded-full shadow-lg">
            <WaterIcon className="w-5 h-5 text-white" />
        </div>
    ),
};

const ConnectionsMap: React.FC<ConnectionsMapProps> = ({ connections, onSelectConnection }) => {
    if (connections.length === 0) {
        return <div className="text-center p-8">No connections to display on the map.</div>;
    }

    const bounds = L.latLngBounds(connections.map(c => [c.latitude, c.longitude]));


    return (
        <div className="h-[450px] rounded-lg overflow-hidden z-0">
             <MapContainer
                bounds={bounds.pad(0.1)}
                scrollWheelZoom={true}
                style={{ height: '100%', width: '100%' }}
            >
                <TileLayer
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />
                {connections.map(connection => (
                    <Marker
                        key={connection.id}
                        position={[connection.latitude, connection.longitude]}
                        icon={productIcons[connection.product]}
                        eventHandlers={{
                            click: () => {
                                onSelectConnection(connection);
                            }
                        }}
                    >
                    </Marker>
                ))}
            </MapContainer>
        </div>
    );
};

export default ConnectionsMap;
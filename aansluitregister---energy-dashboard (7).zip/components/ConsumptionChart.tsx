import React from 'react';
import { ConsumptionDataPoint } from '../types';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface ConsumptionChartProps {
  data: ConsumptionDataPoint[];
  granularity: 'day' | 'month' | 'year';
  unit: string;
}

const CustomTooltip = ({ active, payload, label, unit }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="p-2 bg-slate-800 border border-slate-600 rounded-md shadow-lg">
        <p className="label font-bold text-slate-100">{`${label}`}</p>
        <p className="intro text-cyan-400">{`Usage : ${payload[0].value.toLocaleString()} ${unit}`}</p>
      </div>
    );
  }

  return null;
};

const ConsumptionChart: React.FC<ConsumptionChartProps> = ({ data, granularity, unit }) => {
    
  const formatDate = (tick: string) => {
      const date = new Date(tick);
      switch(granularity) {
          case 'day':
              return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
          case 'month':
              return date.toLocaleDateString('en-US', { month: 'short', year: '2-digit' });
          case 'year':
              return date.toLocaleDateString('en-US', { year: 'numeric' });
          default:
              return tick;
      }
  };

  return (
    <div style={{ width: '100%', height: 300 }}>
        <ResponsiveContainer>
            <LineChart
                data={data}
                margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                }}
            >
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 255, 255, 0.1)" />
                <XAxis 
                    dataKey="date" 
                    tickFormatter={formatDate}
                    tick={{ fill: '#94a3b8' }}
                    className="text-xs"
                />
                <YAxis 
                    tick={{ fill: '#94a3b8' }} 
                    className="text-xs"
                    label={{ value: unit, angle: -90, position: 'insideLeft', fill: '#94a3b8', dy: 40, dx: -10 }}
                />
                <Tooltip content={<CustomTooltip unit={unit}/>} />
                <Legend wrapperStyle={{ color: '#94a3b8' }}/>
                <Line type="monotone" dataKey="usage" stroke="#06b6d4" strokeWidth={2} dot={{ r: 4, stroke: '#06b6d4', fill: '#0f172a' }} activeDot={{ r: 8, fill: '#06b6d4' }} name={`Consumption (${unit})`} />
            </LineChart>
        </ResponsiveContainer>
    </div>
  );
};

export default ConsumptionChart;
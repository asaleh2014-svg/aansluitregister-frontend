import React, { useMemo } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { Connection, ProductType } from '../types';

interface PortfolioCompositionChartProps {
    connections: Connection[];
}

const COLORS = {
    [ProductType.ELEKTRA]: '#f59e0b', // amber-500
    [ProductType.GAS]: '#38bdf8',     // sky-400
    [ProductType.WATER]: '#06b6d4',   // cyan-500
};

const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="p-2 bg-slate-800 border border-slate-600 rounded-md shadow-lg">
        <p className="label font-bold text-slate-100">{`${data.name}: ${data.value} connection${data.value > 1 ? 's' : ''}`}</p>
      </div>
    );
  }
  return null;
};


const PortfolioCompositionChart: React.FC<PortfolioCompositionChartProps> = ({ connections }) => {
    const data = useMemo(() => {
        if (!connections) return [];
        const counts = connections.reduce((acc, conn) => {
            const product = conn.product || 'Unknown';
            acc[product] = (acc[product] || 0) + 1;
            return acc;
        }, {} as Record<string, number>);

        return Object.entries(counts).map(([name, value]) => ({ name, value }));
    }, [connections]);

    if (!connections || connections.length === 0) {
        return <div className="text-slate-400">No data for chart.</div>
    }

    return (
        <div className="h-full flex flex-col">
            <h2 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4">Portfolio Composition</h2>
            <div className="flex-grow" style={{ width: '100%', minHeight: 300 }}>
                <ResponsiveContainer>
                    <PieChart>
                        <Pie
                            data={data}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={110}
                            fill="#8884d8"
                            dataKey="value"
                            nameKey="name"
                            label={({ cx, cy, midAngle, innerRadius, outerRadius, percent, index }) => {
                                const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
                                const x = cx + radius * Math.cos(-midAngle * (Math.PI / 180));
                                const y = cy + radius * Math.sin(-midAngle * (Math.PI / 180));
                                return (
                                <text x={x} y={y} fill="white" textAnchor={x > cx ? 'start' : 'end'} dominantBaseline="central">
                                    {`${(percent * 100).toFixed(0)}%`}
                                </text>
                                );
                            }}
                        >
                            {data.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[entry.name as ProductType] || '#64748b'} />
                            ))}
                        </Pie>
                        <Tooltip content={<CustomTooltip />} />
                        <Legend wrapperStyle={{ color: '#94a3b8' }} />
                    </PieChart>
                </ResponsiveContainer>
            </div>
        </div>
    );
};

export default PortfolioCompositionChart;

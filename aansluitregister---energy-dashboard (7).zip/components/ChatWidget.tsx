import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage } from '../types';
import { ChatBotIcon, XIcon, LogoIcon, LinkIcon } from './icons/Icons';
import { ParsedMarkdown } from './ParsedMarkdown';

interface ChatWidgetProps {
    messages: ChatMessage[];
    onSendMessage: (message: string) => void;
    isLoading: boolean;
}

const ChatWidget: React.FC<ChatWidgetProps> = ({ messages, onSendMessage, isLoading }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [input, setInput] = useState('');
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(scrollToBottom, [messages, isLoading]);
    
    useEffect(() => {
        if(isOpen && messages.length === 0) {
            // Can add an initial welcome message if desired
        }
    }, [isOpen]);

    const handleSend = () => {
        if (input.trim() && !isLoading) {
            onSendMessage(input.trim());
            setInput('');
        }
    };

    return (
        <>
            <div className={`fixed bottom-0 right-0 m-6 z-[1000] transition-all duration-300 ${isOpen ? 'opacity-0 scale-90 pointer-events-none' : 'opacity-100 scale-100'}`}>
                <button
                    onClick={() => setIsOpen(true)}
                    className="bg-cyan-600 text-white rounded-full p-4 shadow-lg hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-cyan-500"
                    aria-label="Open AI Chat"
                >
                    <ChatBotIcon className="w-8 h-8" />
                </button>
            </div>

            <div className={`fixed bottom-0 right-0 z-[1000] mb-6 mx-6 transition-all duration-300 ease-in-out ${isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10 pointer-events-none'} w-[90vw] max-w-lg h-[70vh] flex flex-col bg-slate-800 rounded-2xl shadow-2xl border border-slate-700`}>
                {/* Header */}
                <div className="flex items-center justify-between p-4 border-b border-slate-700 flex-shrink-0">
                    <h3 className="text-lg font-semibold text-slate-100">AI Assistant</h3>
                    <button onClick={() => setIsOpen(false)} className="p-1 rounded-full text-slate-400 hover:bg-slate-700">
                        <XIcon className="w-6 h-6" />
                    </button>
                </div>

                {/* Messages */}
                <div className="flex-grow p-4 overflow-y-auto">
                    <div className="space-y-4">
                        {messages.map((msg, index) => (
                            <div key={index} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                                <div className={`max-w-md p-3 rounded-xl ${msg.role === 'user' ? 'bg-cyan-600 text-white' : 'bg-slate-700 text-slate-100'}`}>
                                    {msg.role === 'model' ? <ParsedMarkdown text={msg.text} /> : <p className="text-sm whitespace-pre-wrap">{msg.text}</p>}
                                </div>
                                {msg.sources && msg.sources.length > 0 && (
                                     <div className="mt-2 max-w-md w-full border-t border-slate-600 pt-2">
                                        <h4 className="text-xs font-semibold text-slate-400 mb-1">Sources:</h4>
                                        <div className="space-y-1">
                                            {msg.sources.map((source, i) => (
                                                <a 
                                                    key={i} 
                                                    href={source.uri} 
                                                    target="_blank" 
                                                    rel="noopener noreferrer"
                                                    className="flex items-start text-xs text-cyan-400 hover:underline"
                                                >
                                                    <LinkIcon className="w-3 h-3 mr-1.5 mt-0.5 flex-shrink-0" />
                                                    <span className="truncate">{source.title}</span>
                                                </a>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </div>
                        ))}
                        {isLoading && (
                             <div className="flex justify-start">
                                <div className="max-w-md p-3 rounded-xl bg-slate-700 text-slate-100 flex items-center space-x-2">
                                   <LogoIcon className="w-5 h-5 text-cyan-500 animate-pulse"/>
                                   <span className="text-sm text-slate-400">Thinking...</span>
                                </div>
                            </div>
                        )}
                         <div ref={messagesEndRef} />
                    </div>
                </div>
                
                {/* Input */}
                <div className="p-4 border-t border-slate-700 flex-shrink-0">
                     <div className="flex items-center space-x-2">
                        <input
                            type="text"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                            placeholder="Ask a question..."
                            className="w-full p-2 text-sm text-white bg-slate-700 border border-slate-600 rounded-md focus:ring-cyan-500 focus:border-cyan-500"
                            disabled={isLoading}
                        />
                        <button
                            onClick={handleSend}
                            disabled={isLoading}
                            className="px-4 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700 disabled:bg-cyan-800 disabled:cursor-not-allowed"
                        >
                            Send
                        </button>
                    </div>
                </div>
            </div>
        </>
    );
};

export default ChatWidget;
import React, { useState } from 'react';
import { ArrowDownIcon, ChevronRightIcon } from './icons/Icons';

interface CollapsibleSectionProps {
    title: string;
    children: React.ReactNode;
    defaultOpen?: boolean;
}

const CollapsibleSection: React.FC<CollapsibleSectionProps> = ({ title, children, defaultOpen = false }) => {
    const [isOpen, setIsOpen] = useState(defaultOpen);

    return (
        <div className="border border-slate-700 rounded-lg bg-slate-800">
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="w-full flex items-center justify-between p-4 bg-slate-800 hover:bg-slate-700/50 focus:outline-none transition-colors rounded-t-lg"
                aria-expanded={isOpen}
            >
                <h3 className="text-lg font-semibold text-slate-200">{title}</h3>
                {isOpen ? <ArrowDownIcon className="w-5 h-5 text-slate-400" /> : <ChevronRightIcon className="w-5 h-5 text-slate-400" />}
            </button>
            {isOpen && (
                <div className="p-4 border-t border-slate-700">
                    {children}
                </div>
            )}
        </div>
    );
};

export default CollapsibleSection;
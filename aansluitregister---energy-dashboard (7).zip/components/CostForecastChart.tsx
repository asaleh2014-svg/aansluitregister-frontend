import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { ForecastDataPoint, ProductType } from '../types';
import { fetchForecastCostData } from '../services/energyService';

const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const total = payload.reduce((sum: number, entry: any) => sum + (entry.hide ? 0 : entry.value), 0);
      return (
        <div className="p-3 bg-slate-800 border border-slate-600 rounded-md shadow-lg">
          <p className="label font-bold text-slate-100">{label}</p>
          {payload.map((entry: any) => (
              !entry.hide &&
              <p key={entry.name} style={{ color: entry.color }}>
                  {`${entry.name}: €${entry.value.toLocaleString('nl-NL', {minimumFractionDigits: 2})}`}
              </p>
          ))}
          <p className="font-semibold mt-2 pt-2 border-t border-slate-600 text-slate-100">
            Total: €{total.toLocaleString('nl-NL', {minimumFractionDigits: 2})}
          </p>
        </div>
      );
    }
    return null;
};
  
const CostForecastChart: React.FC = () => {
    const [data, setData] = useState<ForecastDataPoint[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [selectedProduct, setSelectedProduct] = useState<ProductType | 'All'>('All');
    const [visibleCategories, setVisibleCategories] = useState({
        commodity: true,
        nonCommodity: true,
    });

    useEffect(() => {
        const loadData = async () => {
            setIsLoading(true);
            const forecastData = await fetchForecastCostData(selectedProduct);
            setData(forecastData);
            setIsLoading(false);
        };
        loadData();
    }, [selectedProduct]);

    const handleLegendClick = (data: any) => {
        const { dataKey } = data;
        setVisibleCategories(prev => ({
            ...prev,
            [dataKey]: !prev[dataKey as keyof typeof prev],
        }))
    };

    if(isLoading) {
        return (
            <div className="flex items-center justify-center h-[350px]">
                <svg className="w-8 h-8 text-cyan-500 animate-spin" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"></path>
                </svg>
            </div>
        );
    }

    return (
        <div className="h-full flex flex-col">
            <div className="flex flex-wrap items-center justify-between mb-4 gap-4">
                 <h2 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total Cost Forecast (Monthly)</h2>
                 <select
                    value={selectedProduct}
                    onChange={(e) => setSelectedProduct(e.target.value as ProductType | 'All')}
                    className="block pl-3 pr-8 py-1.5 text-sm text-white bg-slate-700 border border-slate-600 rounded-md focus:outline-none focus:ring-cyan-500 focus:border-cyan-500"
                 >
                    <option value="All">All Products</option>
                    <option value={ProductType.ELEKTRA}>Electricity</option>
                    <option value={ProductType.GAS}>Gas</option>
                    <option value={ProductType.WATER}>Water</option>
                 </select>
            </div>
            <div className="flex-grow" style={{ width: '100%', minHeight: 300 }}>
                <ResponsiveContainer>
                    <BarChart data={data} margin={{ top: 5, right: 10, left: 10, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 255, 255, 0.1)" />
                        <XAxis 
                            dataKey="month" 
                            tick={{ fill: '#94a3b8' }}
                            className="text-xs"
                        />
                        <YAxis 
                            tickFormatter={(value) => `€${value}`}
                            tick={{ fill: '#94a3b8' }} 
                            className="text-xs"
                        />
                        <Tooltip content={<CustomTooltip />} />
                        <Legend onClick={handleLegendClick} wrapperStyle={{ color: '#94a3b8' }} />
                        <Bar dataKey="commodity" stackId="a" fill="#06b6d4" name="Commodity" hide={!visibleCategories.commodity} />
                        <Bar dataKey="nonCommodity" stackId="a" fill="#38bdf8" name="Non-Commodity" hide={!visibleCategories.nonCommodity} />
                    </BarChart>
                </ResponsiveContainer>
            </div>
        </div>
    );
};

export default CostForecastChart;
import React from 'react';
import { ConnectionType, ProductType, ConnectionStatus } from '../types';
import { FilterIcon } from './icons/Icons';

export interface FilterState {
  client: string;
  department: string;
  connectionName: string;
  ean: string;
  address: string;
  city: string;
  country: string;
  product: 'All' | ProductType;
  connectionType: 'All' | ConnectionType;
  status: 'All' | ConnectionStatus;
}

interface FilterPanelProps {
  filters: FilterState;
  onFilterChange: (filters: FilterState) => void;
  onReset: () => void;
  accessibleClients: string[];
}

const FilterInput: React.FC<{
    name: keyof FilterState;
    label: string;
    value: string;
    placeholder: string;
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}> = ({ name, label, value, placeholder, onChange }) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-slate-300">{label}</label>
        <input
            type="text"
            name={name}
            id={name}
            value={value}
            onChange={onChange}
            placeholder={placeholder}
            className="mt-1 block w-full text-white bg-slate-700 border border-slate-600 rounded-md shadow-sm placeholder-slate-400 focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm p-2"
        />
    </div>
);

const FilterPanel: React.FC<FilterPanelProps> = ({ filters, onFilterChange, onReset, accessibleClients }) => {
    
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    onFilterChange({
      ...filters,
      [name]: value,
    });
  };

  return (
    <div className="h-full">
      <div className="flex items-center justify-between mb-4 border-b border-slate-700 pb-2">
        <h2 className="text-xl font-bold text-slate-200">Filters</h2>
        <FilterIcon className="w-6 h-6 text-slate-400" />
      </div>
      <div className="grid grid-cols-1 gap-4">
        
        {/* Client */}
        <div>
          <label htmlFor="client" className="block text-sm font-medium text-slate-300">Client</label>
          <select
            id="client"
            name="client"
            value={filters.client}
            onChange={handleInputChange}
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base text-white bg-slate-700 border border-slate-600 rounded-md focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
          >
            <option value="All">All Clients</option>
            {accessibleClients.map(clientName => (
                <option key={clientName} value={clientName}>{clientName}</option>
            ))}
          </select>
        </div>

        <FilterInput name="department" label="Department" value={filters.department} placeholder="e.g. Vastgoed" onChange={handleInputChange} />
        <FilterInput name="connectionName" label="Connection Name" value={filters.connectionName} placeholder="e.g. Pomp 1116" onChange={handleInputChange} />
        <FilterInput name="ean" label="EAN Code" value={filters.ean} placeholder="e.g. 871..." onChange={handleInputChange} />
        <FilterInput name="address" label="Address" value={filters.address} placeholder="e.g. Main Street" onChange={handleInputChange} />
        <FilterInput name="city" label="City" value={filters.city} placeholder="e.g. Amsterdam" onChange={handleInputChange} />
        <FilterInput name="country" label="Country" value={filters.country} placeholder="e.g. Netherlands" onChange={handleInputChange} />

        {/* Product Type */}
        <div>
          <label htmlFor="product" className="block text-sm font-medium text-slate-300">Product</label>
          <select
            id="product"
            name="product"
            value={filters.product}
            onChange={handleInputChange}
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base text-white bg-slate-700 border border-slate-600 rounded-md focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
          >
            <option>All</option>
            <option>{ProductType.ELEKTRA}</option>
            <option>{ProductType.GAS}</option>
            <option>{ProductType.WATER}</option>
          </select>
        </div>

        {/* Connection Type */}
        <div>
          <label htmlFor="connectionType" className="block text-sm font-medium text-slate-300">Connection Size</label>
          <select
            id="connectionType"
            name="connectionType"
            value={filters.connectionType}
            onChange={handleInputChange}
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base text-white bg-slate-700 border border-slate-600 rounded-md focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
          >
            <option>All</option>
            <option>{ConnectionType.LARGE}</option>
            <option>{ConnectionType.SMALL}</option>
          </select>
        </div>

        {/* Status */}
        <div>
          <label htmlFor="status" className="block text-sm font-medium text-slate-300">Status</label>
          <select
            id="status"
            name="status"
            value={filters.status}
            onChange={handleInputChange}
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base text-white bg-slate-700 border border-slate-600 rounded-md focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
          >
            <option>All</option>
            <option>{ConnectionStatus.ACTIVE}</option>
            <option>{ConnectionStatus.INACTIVE}</option>
          </select>
        </div>

        <div className="flex justify-end pt-4">
            <button
                onClick={onReset}
                className="px-4 py-2 text-sm font-medium bg-slate-700 border border-slate-600 rounded-md shadow-sm text-slate-200 hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-cyan-500"
            >
                Reset Filters
            </button>
        </div>
      </div>
    </div>
  );
};

export default FilterPanel;
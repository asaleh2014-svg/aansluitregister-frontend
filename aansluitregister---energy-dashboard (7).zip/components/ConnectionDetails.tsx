import React, { useState, useEffect, useMemo } from 'react';
import { Connection, Meter, ProductType, ConsumptionDataPoint, Note, UserData, ConnectionType, ConnectionStatus, EditHistoryEntry } from '../types';
import { fetchConsumptionData } from '../services/energyService';
import ConsumptionChart from './ConsumptionChart';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import { ElectricityIcon, GasIcon, MeterIcon, CalendarIcon, BackIcon, WaterIcon, EditIcon, RestoreIcon } from './icons/Icons';
import CollapsibleSection from './CollapsibleSection';

interface ConnectionDetailsProps {
  connection: Connection | null;
  onBack: () => void;
  onUpdateConnection: (connection: Connection) => void;
  user: UserData | null;
}

const InfoRow: React.FC<{label: string, value: string | number}> = ({ label, value }) => (
    <div className="grid grid-cols-2 gap-2 py-1.5 px-2 even:bg-slate-800/50 rounded-md">
        <dt className="text-sm font-medium text-slate-400">{label}</dt>
        <dd className="text-sm text-slate-100">{value}</dd>
    </div>
);

const EditableInfoRow: React.FC<{
    label: string;
    value: string | number;
    name: string;
    onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
    type?: string;
    options?: string[];
}> = ({ label, value, name, onChange, type = 'text', options }) => (
    <div className="grid grid-cols-2 gap-2 py-1.5 px-2 items-center">
        <label htmlFor={name} className="text-sm font-medium text-slate-400">{label}</label>
        {type === 'select' ? (
             <select
                name={name}
                id={name}
                value={value}
                onChange={onChange}
                className="w-full text-sm p-1 text-white bg-slate-700 border border-slate-600 rounded-md focus:ring-cyan-500 focus:border-cyan-500"
            >
                {options?.map(opt => <option key={opt} value={opt}>{opt}</option>)}
            </select>
        ) : (
            <input
                type={type}
                name={name}
                id={name}
                value={value}
                onChange={onChange}
                className="w-full text-sm p-1 text-white bg-slate-700 border border-slate-600 rounded-md focus:ring-cyan-500 focus:border-cyan-500"
            />
        )}
    </div>
);


const MeterCard: React.FC<{ meter: Meter }> = ({ meter }) => {
  const isElectricity = meter.type === ProductType.ELEKTRA;
  const isGas = meter.type === ProductType.GAS;
  const isWater = meter.type === ProductType.WATER;
  
  const getIcon = () => {
      if (isElectricity) return <ElectricityIcon className="w-6 h-6 text-yellow-400" />;
      if (isGas) return <GasIcon className="w-6 h-6 text-sky-400" />;
      if (isWater) return <WaterIcon className="w-6 h-6 text-cyan-400" />;
      return null;
  }

  const getBgClass = () => {
      if (isElectricity) return 'bg-yellow-500/10';
      if (isGas) return 'bg-sky-500/10';
      if (isWater) return 'bg-cyan-500/10';
      return 'bg-slate-500/10';
  }

  return (
    <div className="bg-slate-700/50 p-4 rounded-lg space-y-3">
        <div className="flex items-start space-x-4">
            <div className={`p-3 rounded-full ${getBgClass()}`}>
                {getIcon()}
            </div>
            <div>
                <h4 className="font-semibold text-slate-100">{meter.type} - {meter.meterType}</h4>
                <p className="text-sm text-slate-400">Meter Number: {meter.id}</p>
            </div>
        </div>
        <div>
            <div className="text-sm text-slate-300">
                <strong>Registration Reading:</strong> {meter.registrationReading.toLocaleString()} {meter.unit}
            </div>
            <div className="text-sm text-slate-300">
                <strong>Last Reading:</strong> {meter.lastReading.toLocaleString()} {meter.unit}
            </div>
            <div className="text-sm text-slate-400 mt-1">
                <div className="flex items-center">
                    <CalendarIcon className="w-4 h-4 mr-2" />
                    <span>{meter.lastReadingDate}</span>
                </div>
            </div>
        </div>
    </div>
  );
};

const getISODateString = (date: Date) => date.toISOString().split('T')[0];

const ConnectionDetails: React.FC<ConnectionDetailsProps> = ({ connection, onBack, onUpdateConnection, user }) => {
  type Granularity = 'day' | 'month' | 'year';
  const [granularity, setGranularity] = useState<Granularity>('day');
  const [consumptionData, setConsumptionData] = useState<ConsumptionDataPoint[]>([]);
  const [isLoadingChart, setIsLoadingChart] = useState(true);
  const [gasUnit, setGasUnit] = useState<'m³' | 'kWh'>('m³');
  const [showInMwh, setShowInMwh] = useState(false);

  const [isEditing, setIsEditing] = useState(false);
  const [editableConnection, setEditableConnection] = useState<Connection | null>(connection);
  const [newNoteText, setNewNoteText] = useState('');

  useEffect(() => {
      setEditableConnection(connection);
  }, [connection]);
  
  const handleRootChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setEditableConnection(prev => {
        if (!prev) return null;
        return { ...prev, [name]: value };
    });
  };

  const handleNestedChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>, section: keyof Connection) => {
    const { name, value } = e.target;
    setEditableConnection(prev => {
        if (!prev) return null;
        const sectionData = prev[section];
        if (typeof sectionData === 'object' && sectionData !== null) {
            return {
                ...prev,
                [section]: {
                    ...(sectionData as object),
                    [name]: value,
                }
            };
        }
        return { ...prev, [name]: value };
    });
  };

  const handleMeterChange = (index: number, e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setEditableConnection(prev => {
        if (!prev) return null;
        const updatedMeters = [...prev.meters];
        const meterToUpdate = { ...updatedMeters[index] };
        
        let processedValue: string | number = value;
        if (e.target.type === 'number') {
            processedValue = parseFloat(value);
        }

        (meterToUpdate as any)[name] = processedValue;
        
        if (name === 'type') {
            meterToUpdate.unit = value === ProductType.WATER ? 'm³' : 'kWh';
        }

        updatedMeters[index] = meterToUpdate;
        return { ...prev, meters: updatedMeters };
    });
  };


  const handleSave = () => {
    if (editableConnection) {
        onUpdateConnection(editableConnection);
    }
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditableConnection(connection);
    setIsEditing(false);
  };
  
  const handleAddNote = () => {
    if (!newNoteText.trim() || !user) return;
    const newNote: Note = {
        text: newNoteText.trim(),
        user: user.name,
        date: new Date().toISOString(),
    };
    setEditableConnection(prev => {
        if (!prev) return null;
        return {
            ...prev,
            notes: [...(prev.notes || []), newNote]
        };
    });
    setNewNoteText('');
  };

  const handleRestore = (historyEntry: EditHistoryEntry) => {
    if (window.confirm('Are you sure you want to restore this version? The current data will be saved as a new history point.')) {
        onUpdateConnection(historyEntry.snapshot);
        setIsEditing(false);
    }
  };


  const today = new Date();
  const oneMonthAgo = new Date(new Date().setMonth(today.getMonth() - 1));
  const [dateRange, setDateRange] = useState({
      start: getISODateString(oneMonthAgo),
      end: getISODateString(today)
  });

  useEffect(() => {
    if (connection) {
      const loadConsumption = async () => {
        setIsLoadingChart(true);
        const data = await fetchConsumptionData(connection.id, dateRange.start, dateRange.end, granularity);
        setConsumptionData(data);
        setIsLoadingChart(false);
      }
      loadConsumption();
    }
  }, [connection, granularity, dateRange]);
  
  const { processedData, displayUnit } = useMemo(() => {
    if (!connection) return { processedData: [], displayUnit: '' };
    
    let baseUnit: 'kWh' | 'm³' = connection.meters[0]?.unit || 'kWh';
    if (connection.product === ProductType.WATER) baseUnit = 'm³';

    let unit: string = baseUnit;
    let data = [...consumptionData];

    if (connection.product === ProductType.GAS) {
        if (gasUnit === 'kWh') {
            unit = 'kWh';
            if(baseUnit === 'm³') { // Only convert if original data is in m³
                data = data.map(d => ({ ...d, usage: parseFloat((d.usage * 9.769).toFixed(3)) }));
            }
        } else {
            unit = 'm³';
        }
    }
    
    if (showInMwh && unit === 'kWh') {
        unit = 'MWh';
        data = data.map(d => ({ ...d, usage: parseFloat((d.usage / 1000).toFixed(5)) }));
    }

    return { processedData: data, displayUnit: unit };
  }, [consumptionData, connection, gasUnit, showInMwh]);


  if (!connection || !editableConnection) {
    return (
        <div className="flex items-center justify-center h-full p-6 bg-slate-800 rounded-lg border border-slate-700">
            <div className="text-center">
                <h3 className="text-lg font-medium text-slate-100">No Connection Data</h3>
                <p className="mt-1 text-sm text-slate-400">
                    Please go back and select a connection to view its details.
                </p>
            </div>
        </div>
    );
  }
  
  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      setDateRange(prev => ({...prev, [e.target.name]: e.target.value }));
  };
  
  const mapPosition: [number, number] = [connection.latitude, connection.longitude];
  const canShowMwh = connection.product === ProductType.ELEKTRA || (connection.product === ProductType.GAS && gasUnit === 'kWh');


  return (
    <div className="space-y-6">
        <div className="flex items-center justify-between">
            <button
                onClick={onBack}
                className="flex items-center px-4 py-2 text-sm font-medium bg-slate-700 border border-slate-600 rounded-md shadow-sm text-slate-200 hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-cyan-500"
            >
                <BackIcon className="w-5 h-5 mr-2" />
                Back to Connections
            </button>

            {isEditing ? (
                <div className="flex items-center space-x-2">
                     <button
                        onClick={handleCancel}
                        className="px-4 py-2 text-sm font-medium bg-slate-700 border border-slate-600 rounded-md shadow-sm text-slate-200 hover:bg-slate-600"
                    >
                        Cancel
                    </button>
                    <button
                        onClick={handleSave}
                        className="px-4 py-2 text-sm font-medium text-white bg-cyan-600 border border-transparent rounded-md shadow-sm hover:bg-cyan-700"
                    >
                        Save Changes
                    </button>
                </div>
            ) : (
                <button
                    onClick={() => setIsEditing(true)}
                    className="flex items-center px-4 py-2 text-sm font-medium text-white bg-cyan-600 border border-transparent rounded-md shadow-sm hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-cyan-500"
                >
                    <EditIcon className="w-5 h-5 mr-2" />
                    Edit Connection
                </button>
            )}
        </div>


      <div className="bg-slate-800 rounded-lg border border-slate-700 p-6">
        {isEditing ? (
            <div className="space-y-4">
                 <EditableInfoRow label="Address" name="address" value={editableConnection.address} onChange={handleRootChange} />
                 <EditableInfoRow label="Postal Code" name="postalCode" value={editableConnection.postalCode} onChange={handleRootChange} />
                 <EditableInfoRow label="City" name="city" value={editableConnection.city} onChange={handleRootChange} />
                 <EditableInfoRow label="Country" name="country" value={editableConnection.country} onChange={handleRootChange} />
                 <EditableInfoRow label="EAN Code" name="ean" value={editableConnection.ean} onChange={handleRootChange} />
            </div>
        ) : (
            <>
                <h2 className="text-2xl font-bold text-slate-100">{connection.address}</h2>
                <p className="text-slate-400">{connection.postalCode} {connection.city}, {connection.country}</p>
                <p className="mt-2 text-sm text-slate-300">
                  <span className="font-semibold">EAN Code:</span> {connection.ean}
                </p>
            </>
        )}
      </div>

       <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-6">
              <CollapsibleSection title="Supplier Information">
                  <dl>
                    {isEditing ? (
                        <>
                            <EditableInfoRow label="Name" name="name" value={editableConnection.supplierInfo.name} onChange={(e) => handleNestedChange(e, 'supplierInfo')} />
                            <EditableInfoRow label="Delivery Start" name="startDate" value={editableConnection.supplierInfo.startDate} onChange={(e) => handleNestedChange(e, 'supplierInfo')} type="date" />
                            <EditableInfoRow label="Delivery End" name="endDate" value={editableConnection.supplierInfo.endDate} onChange={(e) => handleNestedChange(e, 'supplierInfo')} type="date" />
                            <EditableInfoRow label="Contact" name="contact" value={editableConnection.supplierInfo.contact} onChange={(e) => handleNestedChange(e, 'supplierInfo')} />
                        </>
                    ) : (
                        <>
                           <InfoRow label="Name" value={connection.supplierInfo.name} />
                           <InfoRow label="Delivery Start" value={new Date(connection.supplierInfo.startDate).toLocaleDateString()} />
                           <InfoRow label="Delivery End" value={new Date(connection.supplierInfo.endDate).toLocaleDateString()} />
                           <InfoRow label="Contact" value={connection.supplierInfo.contact} />
                        </>
                    )}
                  </dl>
              </CollapsibleSection>
              <CollapsibleSection title="Network Operator Information">
                  <dl>
                       {isEditing ? (
                        <>
                            <EditableInfoRow label="Name" name="name" value={editableConnection.networkOperatorInfo.name} onChange={(e) => handleNestedChange(e, 'networkOperatorInfo')} />
                            <EditableInfoRow label="Contact" name="contact" value={editableConnection.networkOperatorInfo.contact} onChange={(e) => handleNestedChange(e, 'networkOperatorInfo')} />
                        </>
                    ) : (
                        <>
                            <InfoRow label="Name" value={connection.networkOperatorInfo.name} />
                            <InfoRow label="Contact" value={connection.networkOperatorInfo.contact} />
                        </>
                    )}
                  </dl>
              </CollapsibleSection>
              <CollapsibleSection title="Technical Data">
                  <dl>
                    {isEditing ? (
                        <>
                            <EditableInfoRow label="Connection Type" name="connectionType" value={editableConnection.connectionType} onChange={(e) => handleRootChange(e)} type="select" options={[ConnectionType.LARGE, ConnectionType.SMALL]} />
                            <EditableInfoRow label="Capacity" name="capacity" value={editableConnection.technicalData.capacity} onChange={(e) => handleNestedChange(e, 'technicalData')} />
                            <EditableInfoRow label="Physical Status" name="physicalStatus" value={editableConnection.technicalData.physicalStatus} onChange={(e) => handleNestedChange(e, 'technicalData')} />
                        </>
                    ) : (
                        <>
                            <InfoRow label="Connection Type" value={connection.connectionType} />
                            <InfoRow label="Capacity" value={connection.technicalData.capacity} />
                            <InfoRow label="Physical Status" value={connection.technicalData.physicalStatus} />
                        </>
                    )}
                  </dl>
              </CollapsibleSection>
          </div>
          <div className="space-y-6">
              <div className="h-64 rounded-lg overflow-hidden z-0 border border-slate-700">
                  <MapContainer center={mapPosition} zoom={15} scrollWheelZoom={false} style={{height: '100%', width: '100%'}}>
                      <TileLayer
                        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                      />
                      <Marker position={mapPosition}>
                        <Popup>{connection.address}</Popup>
                      </Marker>
                  </MapContainer>
              </div>
              <CollapsibleSection title="Notes">
                    <div className="space-y-3">
                        {editableConnection.notes && editableConnection.notes.length > 0 ? (
                            <div className="space-y-2 max-h-48 overflow-y-auto pr-2">
                                {editableConnection.notes.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map((note, index) => (
                                    <div key={index} className="bg-slate-700/50 p-3 rounded-lg border border-slate-600">
                                        <p className="text-sm text-slate-100">{note.text}</p>
                                        <p className="text-xs text-slate-400 mt-1">
                                            - {note.user} on {new Date(note.date).toLocaleString()}
                                        </p>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <p className="text-sm text-slate-400">No notes yet.</p>
                        )}

                        {isEditing && (
                             <div className="space-y-2 pt-2 border-t border-slate-700">
                                <textarea
                                    value={newNoteText}
                                    onChange={(e) => setNewNoteText(e.target.value)}
                                    rows={3}
                                    className="w-full p-2 text-sm text-white bg-slate-700 border border-slate-600 rounded-md focus:ring-cyan-500 focus:border-cyan-500"
                                    placeholder="Add a new note..."
                                />
                                <div className="flex justify-end">
                                    <button
                                        onClick={handleAddNote}
                                        className="px-4 py-1.5 text-sm font-medium text-white rounded-md bg-cyan-600 hover:bg-cyan-700"
                                    >
                                        Add Note
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>
                </CollapsibleSection>
          </div>
      </div>

       <CollapsibleSection title="Meter Information" defaultOpen={true}>
            {isEditing ? (
                <div className="space-y-4">
                    {editableConnection.meters.map((meter, index) => (
                        <div key={meter.id} className="p-4 border border-slate-700 rounded-lg space-y-2">
                             <EditableInfoRow label="Meter ID" name="id" value={meter.id} onChange={e => handleMeterChange(index, e)} />
                             <EditableInfoRow label="Product Type" name="type" value={meter.type} onChange={e => handleMeterChange(index, e)} type="select" options={Object.values(ProductType)} />
                             <EditableInfoRow label="Meter Type" name="meterType" value={meter.meterType} onChange={e => handleMeterChange(index, e)} type="select" options={['Smart', 'Conventional']} />
                             <EditableInfoRow label="Registration Reading" name="registrationReading" value={meter.registrationReading} onChange={e => handleMeterChange(index, e)} type="number" />
                             <EditableInfoRow label="Last Reading" name="lastReading" value={meter.lastReading} onChange={e => handleMeterChange(index, e)} type="number" />
                             <EditableInfoRow label="Last Reading Date" name="lastReadingDate" value={meter.lastReadingDate} onChange={e => handleMeterChange(index, e)} type="date" />
                        </div>
                    ))}
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                    {connection.meters.map((meter) => (
                      <MeterCard key={meter.id} meter={meter} />
                    ))}
                </div>
            )}
      </CollapsibleSection>

      <div className="bg-slate-800 rounded-lg border border-slate-700 p-6">
        <div className="flex flex-wrap items-center justify-between mb-4 gap-4">
            <h3 className="text-lg font-semibold text-slate-200">Consumption Data</h3>
            <div className="flex items-center gap-2 flex-wrap">
                <div className="flex items-center space-x-2">
                    <input type="date" name="start" value={dateRange.start} onChange={handleDateChange} className="p-2 text-sm text-white bg-slate-700 border border-slate-600 rounded-md"/>
                    <span>-</span>
                    <input type="date" name="end" value={dateRange.end} onChange={handleDateChange} className="p-2 text-sm text-white bg-slate-700 border border-slate-600 rounded-md"/>
                </div>
                <div className="flex rounded-md shadow-sm">
                  {(['day', 'month', 'year'] as Granularity[]).map(g => (
                    <button key={g} onClick={() => setGranularity(g)} className={`px-3 py-2 text-sm capitalize transition-colors duration-200 border -ml-px
                        ${granularity === g ? 'bg-cyan-500 text-white border-cyan-500' : 'bg-slate-700 text-slate-200 border-slate-600 hover:bg-slate-600'}
                        ${g === 'day' ? 'rounded-l-md' : ''} ${g === 'year' ? 'rounded-r-md' : ''}
                    `}>
                        {g}
                    </button>
                  ))}
                </div>
                {connection.product === ProductType.GAS && (
                    <div className="flex rounded-md shadow-sm">
                        {(['m³', 'kWh'] as const).map(u => (
                             <button key={u} onClick={() => setGasUnit(u)} className={`px-3 py-2 text-sm transition-colors duration-200 border -ml-px
                                ${gasUnit === u ? 'bg-cyan-500 text-white border-cyan-500' : 'bg-slate-700 text-slate-200 border-slate-600 hover:bg-slate-600'}
                                ${u === 'm³' ? 'rounded-l-md' : ''} ${u === 'kWh' ? 'rounded-r-md' : ''}
                            `}>
                                {u}
                            </button>
                        ))}
                    </div>
                )}
                {canShowMwh && (
                    <div className="flex items-center space-x-2 pl-2">
                        <input type="checkbox" id="mwh-toggle" checked={showInMwh} onChange={(e) => setShowInMwh(e.target.checked)} className="h-4 w-4 text-cyan-600 bg-slate-700 border-slate-600 rounded focus:ring-cyan-500" />
                        <label htmlFor="mwh-toggle" className="text-sm text-slate-300">Show in MWh</label>
                    </div>
                )}
            </div>
        </div>
        {isLoadingChart ? (
             <div className="flex items-center justify-center h-[300px]">
                <svg className="w-8 h-8 text-cyan-500 animate-spin" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"></path>
                </svg>
             </div>
        ) : (
            <ConsumptionChart data={processedData} granularity={granularity} unit={displayUnit} />
        )}
      </div>

       <CollapsibleSection title="Edit History">
        {connection.editHistory && connection.editHistory.length > 0 ? (
            <div className="space-y-3">
                {/* Sort history descending to show latest first */}
                {[...connection.editHistory].reverse().map((entry, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg border border-slate-600">
                        <div>
                            <p className="text-sm font-medium text-slate-100">
                                Change made on {new Date(entry.date).toLocaleString()}
                            </p>
                            <p className="text-xs text-slate-400">
                                by {entry.user}
                            </p>
                        </div>
                        <button
                            onClick={() => handleRestore(entry)}
                            className="flex items-center px-3 py-1.5 text-xs font-medium text-white bg-cyan-600 border border-transparent rounded-md shadow-sm hover:bg-cyan-700"
                            aria-label={`Restore version from ${new Date(entry.date).toLocaleString()}`}
                        >
                            <RestoreIcon className="w-4 h-4 mr-1.5" />
                            Restore
                        </button>
                    </div>
                ))}
            </div>
        ) : (
            <p className="text-sm text-slate-400">No edit history available.</p>
        )}
    </CollapsibleSection>

    </div>
  );
};

export default ConnectionDetails;
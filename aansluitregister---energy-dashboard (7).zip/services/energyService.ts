import { ConsumptionDataPoint, ForecastDataPoint, HistoricProductCostPoint, ProductType } from '../types';

const API_BASE_URL = '/api';

type Granularity = 'day' | 'month' | 'year';

export const fetchConsumptionData = async (
    connectionId: string,
    startDate: string,
    endDate: string,
    granularity: Granularity
): Promise<ConsumptionDataPoint[]> => {
    try {
        const response = await fetch(`${API_BASE_URL}/consumption?connectionId=${connectionId}&startDate=${startDate}&endDate=${endDate}&granularity=${granularity}`);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return await response.json();
    } catch (error) {
        console.error("Failed to fetch consumption data:", error);
        return [];
    }
};

export const fetchForecastCostData = async (product?: ProductType | 'All'): Promise<ForecastDataPoint[]> => {
    try {
        const response = await fetch(`${API_BASE_URL}/forecasts?product=${product || 'All'}`);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return await response.json();
    } catch (error) {
        console.error("Failed to fetch forecast data:", error);
        return [];
    }
};

export const fetchHistoricCostForConnectionByProduct = async (connectionId: string): Promise<HistoricProductCostPoint[]> => {
    try {
        const response = await fetch(`${API_BASE_URL}/costs/historic/${connectionId}`);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return await response.json();
    } catch (error) {
        console.error("Failed to fetch historic connection cost data:", error);
        return [];
    }
};

export const fetchHistoricCostByProduct = async (): Promise<HistoricProductCostPoint[]> => {
     try {
        const response = await fetch(`${API_BASE_URL}/costs/historic/all`);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return await response.json();
    } catch (error) {
        console.error("Failed to fetch historic total cost data:", error);
        return [];
    }
};